<?php

return [
    /*
     * the application mode
     * local , production
     */
    'mode' => 'local',
'User'
];