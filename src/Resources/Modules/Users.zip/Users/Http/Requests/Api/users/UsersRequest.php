<?php

namespace App\Modules\Users\Http\Requests\Api\Users;

use App\Modules\Users\Models\User;

class UsersRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {
        $array =  [
			'name' => 'required|min:2|max:191',
			'email' => 'required|email|min:6|max:191|unique:users',
			'password' => 'required|nullable|min:6|max:191',
			'avatar' => 'required|image',

        ];

        /*
        *   Override the original rules
        */

       if(request()->route()->methods()  == 'PUT'){
            $user = User::find($this->route()->parameter('user'));
            $overOverRideRules = [
				'email' => 'required|email|min:6|max:191|unique:users,email,'.$user->id,
				'password' => 'min:6|max:191|nullable',
				'avatar' => 'image|nullable',

            ];
             return  $overOverRideRules + $array;
        }

        return $array;

    }
}
