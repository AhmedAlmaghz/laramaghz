<?php

namespace App\Modules\Users\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Modules\Users\Models\User;
use App\Modules\Users\Http\Requests\Admin\Users\UsersRequest;
use Illuminate\Http\Request;
use Almaghz\Laramaghz\Traits\UploadFile;
use Illuminate\Support\Facades\Storage;

class UsersController extends Controller
{

    use UploadFile;
    protected $model;
    protected $request;

    public function __construct(User $model , Request $request)
    {
        $this->model = $model;
        $this->request = $request;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rows = $this->model;

        $rows = $this->order($rows);

        $rows = $this->filter($rows);

        $rows = $rows->paginate(10);

        return view('users::admin.users.index' , compact('rows'));
    }


    /*
    * filter data
    */

    protected function filter($rows){
        if($this->request->has('active') && $this->request->get('active') != ''){
            $rows = $rows->where('active' , $this->request->get('active'));
        }
		if($this->request->has("name") && $this->request->get("name") != ""){
			$rows->where("name" , $this->request->get("name"));
		}
		if($this->request->has("email") && $this->request->get("email") != ""){
			$rows->where("email" , $this->request->get("email"));
		}

        return $rows;
    }

    /*
    * order data
    */

   protected function order($rows){

    $order = $this->request->has('orderByType') ? $this->request->get('orderByType') : "desc";

    if($this->request->has('orderBy') && $this->request->get('orderBy') != ''){
        $rows = $rows->orderBy($this->request->get('orderBy')  , $order);
    }else{
        $rows = $rows->orderBy('id'  , 'desc');
    }

    return $rows;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $row = $this->model;
        return view('users::admin.users.add' , compact('row'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UsersRequest $request)
    {
        $this->request = $request->all();
		$this->uploadFile(['avatar']);
        $row = $this->model->create($this->request);
        return redirect(route('users.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $row = $this->model->findOrfail($id);
        return view('users::admin.users.show' , compact('row'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $row = $this->model->findOrfail($id);
        return view('users::admin.users.edit' , compact('row'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UsersRequest $request, $id)
    {
        $row = $this->model->findOrFail($id);
        $this->request = $request->all();
        if($this->request['password'] === null){
           $this->request = array_except($this->request , "password");
        }
		$this->uploadFile(['avatar'] , $row);
        $row->update($this->request);

        return redirect(route('users.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $row = $this->model->findOrFail($id);
		Storage::delete($row->avatar);

        $row->delete();
        return redirect(route('users.index'));
    }

     /**
     * active the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function active($id){
        $row = $this->model->findOrFail($id);
        if($row->active == 1){
            $row->active = 0;
        }else{
            $row->active = 1;
        }
        $row->save();
        return redirect(route('users.index'));
    }

}
