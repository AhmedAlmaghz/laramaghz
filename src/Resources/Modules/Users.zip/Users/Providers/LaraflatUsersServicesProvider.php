<?php

namespace App\Modules\Users\Providers;

use Illuminate\Support\ServiceProvider;

class LaraflatUsersServicesProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */

    public function boot()
    {
           /*
             * load language files
             */

            $this->loadTranslationsFrom(__DIR__.'/../Resources/lang', 'users');

           /*
            * load  migrations files
            */

            $this->loadMigrationsFrom(__DIR__ . '/../Database/migrations');

          /*
           * load  routes
           */

			$this->loadRoutesFrom(__DIR__ . '/../Routes/admin.php');

			$this->loadRoutesFrom(__DIR__ . '/../Routes/api.php');


           /*
            * load views
            */

            $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'users');

    }

    /**
     * Register services.
     *
     * @return void
     */

    public function register()
    {

        /*
        * merge config file
        */

        $this->mergeConfigFrom(__DIR__ . '/../Config/User.php', 'User');
    }
}
