@extends('laramaghz::admin.layout.app')

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
        <div class="col-sm-7">
        <h1>
            @lang('users::users.users')
        </h1>
        </div>
        <div class="col-sm-5">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}"><i class="fa fa-dashboard"></i> @lang('users::users.home')</a></li>
            <li class="breadcrumb-item"><a href="{{ route('users.index') }}"> @lang('users::users.users')</a></li>
            <li class="breadcrumb-item"><a class="active">@lang('users::users.edit')</a></li>
        </ol>
		</div></div></div>
		
    </section>
    <!-- Main content -->
    <section class="content">
	 <div class="container-fluid">
        <!-- Default box -->
        <div class="box card-info card-outline">
            <div class="box-header with-border">
                <h3 class="box-title">@lang('users::users.edit')</h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-card-widget="collapse">
                        <i class="fa fa-minus"></i></button>
                    <button type="button" class="btn btn-box-tool" data-card-widget="remove">
                        <i class="fa fa-times"></i></button>
                </div>
            </div>
            {!! Form::open(['route' => ['users.update' , $row->id] , 'role' => 'form' , 'files' => true , 'method' => 'PUT']) !!}
                <div class="box-body">
                    @include('users::admin.users.form')
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    {!! Form::submit(trans('users::users.Save') , ['class' => 'btn btn-info']) !!}
                </div>
            {!! Form::close() !!}
            <!-- /.box-footer-->
        </div>
        <!-- /.box -->
		</div>
    </section>
    <!-- /.content -->
@endsection