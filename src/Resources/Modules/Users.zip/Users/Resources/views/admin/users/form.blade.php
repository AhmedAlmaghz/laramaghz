@include("laramaghz::fileds.php.text" , [  "label"  => trans("users::users.name")  , "value" => $row->name ?? null  ,  "name" =>"name" ])
@include("laramaghz::fileds.php.email" , [  "label"  => trans("users::users.email")  , "value" => $row->email ?? null  ,  "name" =>"email" ])
@include("laramaghz::fileds.php.password" , [  "label"  => trans("users::users.password")  ,  "name" =>"password" ])
@include("laramaghz::fileds.php.image" , [  "label"  => trans("users::users.avatar")  , "value" => $row->avatar ?? null  ,  "name" =>"avatar" ])

@include("laramaghz::fileds.php.radio" , [  "label"  => trans("laramaghz::laramaghz.Active") , "array" => [0 => trans("laramaghz::laramaghz.No") , 1 => trans("laramaghz::laramaghz.Yes") ]  , "selectedArray" => (array) $row->active ?? null  ,  "name" =>"active" ])