<?php

return [
	'Users' => 'Users',
	'users' => 'Users',
	'User' => 'User',
	'user' => 'User',
	'name' => 'Name',
	'email' => 'Email',
	'password' => 'Password',
	'avatar' => 'Avatar',
	'Delete' => 'Delete',
	'Edit' => 'Edit',
	'create' => 'Create',
	'index' => 'Index',
	'home' => 'Home',
	'add' => 'Add',
	'Save' => 'Save',
	'edit' => 'Edit',
	'Search' => 'Search',
	'Reset' => 'Reset',
	'Active' => 'Active',

];